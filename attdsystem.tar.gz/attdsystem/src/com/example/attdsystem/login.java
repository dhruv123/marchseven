package com.example.attdsystem;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;

public class login extends Activity {
	
	
	  public void onCreate(Bundle savedInstanceState)
	    {
	        super.onCreate(savedInstanceState);
	        setContentView(R.layout.login);
	        
	        
	    }

	  public void nxtmethod (View v)
	  {
		       // start the home activity
               Intent intent = new Intent(login.this, takeview.class);
               login.this.startActivity(intent);
          }
	  
}
